import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";

@Component({
  selector: 'app-inventory',
  templateUrl: './inventory.component.html',
  styleUrls: ['./inventory.component.css']
})
export class InventoryComponent implements OnInit {
  title = 'inventory';
  public inventoryData: any = []
  constructor(private http: HttpClient) { }

  getData() {
    const url = 'https://mocki.io/v1/0077e191-c3ae-47f6-bbbd-3b3b905e4a60'
    this.http.get<stinedata>(url).subscribe((res: any) => {
      this.inventoryData = res.inventory
      console.log(this.inventoryData)
    })
  }

  ngOnInit(): void {
    this.getData()
  }
}

interface stinedata {
  inventory: Object;
  requests: Object;
}
