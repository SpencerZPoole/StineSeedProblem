import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";

@Component({
  selector: 'app-requests',
  templateUrl: './requests.component.html',
  styleUrls: ['./requests.component.css']
})
export class RequestsComponent implements OnInit {
  title = 'requests';
  public canFulfillRequest: string[] = []
  //public customKernels: number[] = []
  public inventoryData: any = []
  public reqIterId: number = 0
  public requestsData: any = []
  constructor(private http: HttpClient) { }

  getData() {
    const url = 'https://mocki.io/v1/0077e191-c3ae-47f6-bbbd-3b3b905e4a60'
    this.http.get<stinedata>(url).subscribe((res: any) => {
      this.requestsData = res.requests
      this.inventoryData = res.inventory
      for (let request of this.requestsData) {

        if (request.requestedKernels > this.inventoryData[(request.inventoryId) - 1].kernels) {
          this.canFulfillRequest.push('CANNOT FULFILL REQUEST, Inventory ' + request.inventoryId + ' only has ' + this.inventoryData[(request.inventoryId) - 1].kernels + ' kernels.')
        }
        else this.canFulfillRequest.push('Can fulfill request! Inventory ' + request.inventoryId + ' has ' + this.inventoryData[(request.inventoryId) - 1].kernels + ' kernels.')

        this.reqIterId++

        //this.customKernels.push(request.requestedKernels)
        //console.log(this.canFulfillRequest)
      }
    })
    
  }

  ngOnInit(): void {
    this.getData()
    
  }
}

interface stinedata {
  inventory: Object;
  requests: Object;
}
